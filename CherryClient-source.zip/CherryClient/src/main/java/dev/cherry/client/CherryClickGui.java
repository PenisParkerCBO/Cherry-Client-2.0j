package dev.cherry.client;

import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.text.Text;

import java.util.List;

public final class CherryClickGui extends Screen {
    private static final int PINK = 0xFFFF78B7;
    private static final int LIGHT = 0xFFFFC5DE;
    private static final int PANEL = 0xEE17121A;
    private static final int CARD = 0xFF261A25;
    private static final int MUTED = 0xFFB99EAE;

    private String category = "HUD";
    private int panelX, panelY, panelW = 420, panelH = 286;
    private int scroll;

    public CherryClickGui() {
        super(Text.literal("Cherry Client"));
    }

    @Override
    protected void init() {
        panelX = (width - panelW) / 2;
        panelY = (height - panelH) / 2;
    }

    @Override
    public void render(DrawContext ctx, int mouseX, int mouseY, float delta) {
        renderBackground(ctx, mouseX, mouseY, delta);
        ctx.fill(0, 0, width, height, 0x99080012);

        // Main rounded-look panel (layered rectangles)
        ctx.fill(panelX - 1, panelY - 1, panelX + panelW + 1, panelY + panelH + 1, 0xFFFF78B7);
        ctx.fill(panelX, panelY, panelX + panelW, panelY + panelH, PANEL);
        ctx.fill(panelX, panelY, panelX + panelW, panelY + 42, 0xFF241522);

        ctx.drawTextWithShadow(textRenderer, "🍒 CHERRY CLIENT", panelX + 16, panelY + 14, PINK);
        ctx.drawTextWithShadow(textRenderer, "1.21.4  •  FABRIC", panelX + panelW - 112, panelY + 16, MUTED);

        String[] categories = {"HUD", "PvP", "PvE", "Visual", "Movement"};
        int cy = panelY + 56;
        for (String item : categories) {
            boolean selected = item.equals(category);
            int color = selected ? 0xFF63304B : 0xFF30212D;
            ctx.fill(panelX + 12, cy, panelX + 112, cy + 25, color);
            ctx.drawTextWithShadow(textRenderer, item, panelX + 22, cy + 8, selected ? 0xFFFFFFFF : LIGHT);
            cy += 31;
        }

        ctx.drawTextWithShadow(textRenderer, category.toUpperCase(), panelX + 130, panelY + 54, LIGHT);
        ctx.drawTextWithShadow(textRenderer, "Click a module to toggle it", panelX + 130, panelY + 67, MUTED);

        List<CherryModule> modules = CherryModules.ALL.stream()
                .filter(m -> m.category.equals(category)).toList();

        int startY = panelY + 91;
        int rowH = 36;
        int visible = 5;
        for (int i = 0; i < modules.size() && i < visible; i++) {
            CherryModule module = modules.get(i);
            int rowY = startY + i * rowH;
            ctx.fill(panelX + 128, rowY, panelX + panelW - 14, rowY + 30, CARD);
            ctx.drawTextWithShadow(textRenderer, module.name, panelX + 139, rowY + 5,
                    module.enabled ? PINK : 0xFFFFFFFF);
            ctx.drawTextWithShadow(textRenderer, module.description, panelX + 139, rowY + 17, MUTED);
            int toggleX = panelX + panelW - 54;
            ctx.fill(toggleX, rowY + 8, toggleX + 28, rowY + 22,
                    module.enabled ? 0xFFB83D7A : 0xFF594653);
            ctx.fill(toggleX + (module.enabled ? 15 : 2), rowY + 10,
                    toggleX + (module.enabled ? 26 : 13), rowY + 20, 0xFFFFFFFF);
        }

        ctx.drawTextWithShadow(textRenderer, "RIGHT SHIFT  •  CLOSE  •  Cherry Pink UI",
                panelX + 14, panelY + panelH - 18, MUTED);
        super.render(ctx, mouseX, mouseY, delta);
    }

    @Override
    public boolean mouseClicked(double mouseX, double mouseY, int button) {
        if (button != 0) return super.mouseClicked(mouseX, mouseY, button);

        String[] categories = {"HUD", "PvP", "PvE", "Visual", "Movement"};
        int cy = panelY + 56;
        for (String item : categories) {
            if (inside(mouseX, mouseY, panelX + 12, cy, 100, 25)) {
                category = item;
                return true;
            }
            cy += 31;
        }

        List<CherryModule> modules = CherryModules.ALL.stream()
                .filter(m -> m.category.equals(category)).toList();
        int startY = panelY + 91;
        for (int i = 0; i < modules.size() && i < 5; i++) {
            int rowY = startY + i * 36;
            if (inside(mouseX, mouseY, panelX + 128, rowY, panelW - 142, 30)) {
                CherryModule module = modules.get(i);
                module.enabled = !module.enabled;
                CherryConfig.save();
                return true;
            }
        }
        return super.mouseClicked(mouseX, mouseY, button);
    }

    private boolean inside(double x, double y, int rx, int ry, int rw, int rh) {
        return x >= rx && x <= rx + rw && y >= ry && y <= ry + rh;
    }

    @Override
    public boolean shouldPause() {
        return false;
    }
}
