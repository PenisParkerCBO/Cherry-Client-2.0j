package dev.cherry.client;

public final class CherryModule {
    public final String name;
    public final String category;
    public final String description;
    public boolean enabled;

    public CherryModule(String name, String category, String description, boolean enabled) {
        this.name = name;
        this.category = category;
        this.description = description;
        this.enabled = enabled;
    }
}
