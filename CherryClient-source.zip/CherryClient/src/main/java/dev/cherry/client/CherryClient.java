package dev.cherry.client;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.minecraft.client.MinecraftClient;
import org.lwjgl.glfw.GLFW;

public final class CherryClient implements ClientModInitializer {
    private boolean menuWasDown;

    @Override
    public void onInitializeClient() {
        CherryModules.init();
        CherryConfig.load();

        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            if (client.getWindow() == null) return;
            boolean down = GLFW.glfwGetKey(client.getWindow().getHandle(), GLFW.GLFW_KEY_RIGHT_SHIFT)
                    == GLFW.GLFW_PRESS;
            if (down && !menuWasDown && client.currentScreen == null) {
                client.setScreen(new CherryClickGui());
            }
            menuWasDown = down;

            if (client.player != null && CherryModules.AUTO_SPRINT.enabled) {
                client.player.setSprinting(client.player.forwardSpeed > 0.0f);
            }
            if (client.options != null && CherryModules.FULL_BRIGHT.enabled) {
                client.options.getGamma().setValue(16.0);
            }
        });

        HudRenderCallback.EVENT.register((drawContext, tickCounter) -> {
            MinecraftClient client = MinecraftClient.getInstance();
            if (client.player == null || client.options.hudHidden) return;

            int x = 8;
            int y = 8;
            if (CherryModules.WATERMARK.enabled) {
                drawContext.drawTextWithShadow(client.textRenderer, "Cherry Client", x, y, 0xFFFF78B7);
                y += 12;
            }
            if (CherryModules.COORDS.enabled) {
                String coords = String.format("XYZ: %.1f / %.1f / %.1f",
                        client.player.getX(), client.player.getY(), client.player.getZ());
                drawContext.drawTextWithShadow(client.textRenderer, coords, x, y, 0xFFFFC5DE);
                y += 12;
            }
            if (CherryModules.FPS.enabled) {
                drawContext.drawTextWithShadow(client.textRenderer,
                        "FPS: " + client.getCurrentFps(), x, y, 0xFFFFC5DE);
            }
        });
    }
}
