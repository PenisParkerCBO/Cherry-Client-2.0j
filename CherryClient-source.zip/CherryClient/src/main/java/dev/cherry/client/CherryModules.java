package dev.cherry.client;

import java.util.ArrayList;
import java.util.List;

public final class CherryModules {
    public static final List<CherryModule> ALL = new ArrayList<>();

    public static CherryModule WATERMARK, COORDS, FPS, AUTO_SPRINT, FULL_BRIGHT;
    public static CherryModule TARGET_HUD, CPS_DISPLAY, KEYSTROKES;
    public static CherryModule MOB_ESP, ITEM_ESP, AUTO_EAT, AUTO_FISH;
    public static CherryModule AIM_ASSIST, CLICK_ASSIST, REACH_DISPLAY;

    private CherryModules() {}

    private static CherryModule add(String name, String category, String description, boolean enabled) {
        CherryModule module = new CherryModule(name, category, description, enabled);
        ALL.add(module);
        return module;
    }

    public static void init() {
        if (!ALL.isEmpty()) return;

        WATERMARK = add("Watermark", "HUD", "Cherry Client logo on screen", true);
        COORDS = add("Coordinates", "HUD", "Show player coordinates", true);
        FPS = add("FPS", "HUD", "Show current frame rate", true);
        KEYSTROKES = add("Keystrokes", "HUD", "Keystrokes HUD (coming soon)", false);
        TARGET_HUD = add("Target HUD", "HUD", "Target information panel (coming soon)", false);
        CPS_DISPLAY = add("CPS Display", "HUD", "Clicks per second display (coming soon)", false);

        AUTO_SPRINT = add("Auto Sprint", "Movement", "Sprint while moving forward", false);
        FULL_BRIGHT = add("Full Bright", "Visual", "Increase gamma while enabled", false);
        MOB_ESP = add("Mob ESP", "Visual", "Mob highlighting (coming soon)", false);
        ITEM_ESP = add("Item ESP", "Visual", "Dropped item highlighting (coming soon)", false);

        AUTO_EAT = add("Auto Eat", "PvE", "Automatic food use (coming soon)", false);
        AUTO_FISH = add("Auto Fish", "PvE", "Fishing helper (coming soon)", false);

        AIM_ASSIST = add("Aim Assist", "PvP", "Aim assistance (not implemented)", false);
        CLICK_ASSIST = add("Click Assist", "PvP", "Click timing helper (not implemented)", false);
        REACH_DISPLAY = add("Reach Display", "PvP", "Show measured hit distance (coming soon)", false);
    }
}
