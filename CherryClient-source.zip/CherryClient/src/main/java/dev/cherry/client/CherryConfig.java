package dev.cherry.client;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.reflect.TypeToken;
import net.fabricmc.loader.api.FabricLoader;

import java.io.Reader;
import java.io.Writer;
import java.lang.reflect.Type;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Map;
import java.util.stream.Collectors;

public final class CherryConfig {
    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
    private static final Path FILE = FabricLoader.getInstance().getConfigDir().resolve("cherry-client.json");
    private static final Type MAP_TYPE = new TypeToken<Map<String, Boolean>>() {}.getType();

    private CherryConfig() {}

    public static void save() {
        try {
            Files.createDirectories(FILE.getParent());
            Map<String, Boolean> values = CherryModules.ALL.stream()
                    .collect(Collectors.toMap(m -> m.name, m -> m.enabled));
            try (Writer writer = Files.newBufferedWriter(FILE)) {
                GSON.toJson(values, writer);
            }
        } catch (Exception e) {
            System.err.println("[Cherry Client] Could not save config: " + e.getMessage());
        }
    }

    public static void load() {
        if (!Files.exists(FILE)) return;
        try (Reader reader = Files.newBufferedReader(FILE)) {
            Map<String, Boolean> values = GSON.fromJson(reader, MAP_TYPE);
            if (values == null) return;
            CherryModules.ALL.forEach(m -> {
                if (values.containsKey(m.name)) m.enabled = values.get(m.name);
            });
        } catch (Exception e) {
            System.err.println("[Cherry Client] Could not load config: " + e.getMessage());
        }
    }
}
